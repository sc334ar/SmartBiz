SmartBiz PWA files

1) Upload icons/icon-192.png and icons/icon-512.png into your project's:
   static/icons/ folder (create icons if it does not exist).

2) Upload manifest.json into:
   static/manifest.json

3) Add these tags inside the <head> section of your main template (for example templates/dashboard.html):
   <link rel="manifest" href="{{ url_for('static', filename='manifest.json') }}">
   <meta name="theme-color" content="#b80d3c">
   <meta name="mobile-web-app-capable" content="yes">
   <meta name="apple-mobile-web-app-capable" content="yes">
   <meta name="apple-mobile-web-app-title" content="SmartBiz">

4) Optional service worker:
   Do not upload service-worker.js to static and expect it to control the whole site; browsers limit its scope.
   To use it at the site root, add this Flask route to app.py:

   from flask import send_from_directory

   @app.route("/service-worker.js")
   def service_worker():
       return send_from_directory("static", "service-worker.js",
                                  mimetype="application/javascript")

   Then add before </body> in the template:
   <script>
   if ("serviceWorker" in navigator) {
     window.addEventListener("load", () => {
       navigator.serviceWorker.register("/service-worker.js").catch(console.error);
     });
   }
   </script>

5) Deploy on Render (HTTPS is required). Open the site in Chrome on Android, sign in, open the browser menu (⋮), and choose "Install app" or "Add to Home screen" if offered.

Important: This makes a web app installable; it does not create a Play Store APK. Users need internet for account pages and live data. Private business pages are not cached offline.
